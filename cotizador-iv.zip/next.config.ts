/** @type {import('next').NextConfig} */
const nextConfig = {
  // 1. Esto elimina la advertencia (warning) de Cross-Origin
  experimental: {
    allowedDevOrigins: ['192.168.100.98']
  },

  // 2. Tus redirecciones actuales
  async redirects() {
    return [
      {
        source: '/',
        destination: '/login', // O '/dashboard' si prefieres que vaya directo allá
        permanent: true,
      },
    ]
  },
};

export default nextConfig;